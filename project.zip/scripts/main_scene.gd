extends Control

@export var admob : Admob
@export var text_score : Label
@export var loading : Panel
@export var text_loading : Label
var score = 0

func _ready() -> void:
	admob.initialize()

func _on_button_reward_pressed() -> void:
	if admob.initialization_completed :
		admob.load_rewarded_ad()
		loading.show()

func _on_admob_rewarded_ad_loaded(ad_info: AdInfo, response_info: ResponseInfo) -> void:
	admob.show_rewarded_ad()
	loading.hide()
	score += 10
	text_score.text = "SCORE : " + str(score)

func _on_admob_initialization_completed(status_data: InitializationStatus) -> void:
	admob.load_banner_ad()
	admob.show_banner_ad()

func _on_button_interstitial_pressed() -> void:
	admob.load_interstitial_ad()
	loading.show()

func _on_admob_interstitial_ad_loaded(ad_info: AdInfo, response_info: ResponseInfo) -> void:
	admob.show_interstitial_ad()
	loading.hide()

func _on_button_quit_pressed() -> void:
	get_tree().quit()

func timeout():
	if text_loading.text == "LOADING..." :
		text_loading.text = "LOADING.."
	elif text_loading.text == "LOADING.." :
		text_loading.text = "LOADING."
	elif text_loading.text == "LOADING." :
		text_loading.text = "LOADING"
	elif text_loading.text == "LOADING" :
		text_loading.text = "LOADING..."
